<?php
$servername = 'localhost:3306';
$username_db = 'root';
$password_db = '';
$database_name = 'film_library';

$email = $_POST['email'];
$password = $_POST['password'];

$conn = new mysqli($servername, $username_db, $password_db, $database_name);

if ($email === $email && $password === $password) {
    $_SESSION['loggedin'] = true;
    header('location: read.php'); // Redirect ke halaman setelah login berhasil
    exit();
} else {
    echo 'Login gagal. Silakan coba lagi.';
}
?>
