<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['login_email'];
    $password = $_POST['login_password'];

    $conn = new mysqli('localhost', 'root', '', 'db_sekolah');
    if ($conn->connect_error) {
        die('Koneksi gagal: ' . $conn->connect_error);
    }

    $sql = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $_SESSION['login_user'] = $email;
        header('Location: Welcome.php');
    } else {
        echo 'Login gagal. Periksa kembali kredensial Anda.';
    }

    $conn->close();
}

?>
